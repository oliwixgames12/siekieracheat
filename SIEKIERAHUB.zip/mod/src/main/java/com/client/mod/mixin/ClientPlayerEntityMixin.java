package com.client.mod.mixin;

import com.client.mod.ClientMod;
import com.client.mod.modules.combat.KillAura;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.client.input.Input;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(ClientPlayerEntity.class)
public class ClientPlayerEntityMixin {

    @Inject(method = "tickMovement", at = @At("HEAD"))
    private void onTickMovement(CallbackInfo ci) {
        MinecraftClient client = MinecraftClient.getInstance();
        if (client.player == null) return;

        KillAura ka = ClientMod.moduleManager.killAura;
        if (!ka.enabled) return;

        // MoveFix: prevent forced movement in focused mode
        if (ka.moveFix && ka.moveFixFocused) {
            // Focused mode: when pressing W, move towards server yaw
            // This is handled by not overriding movement
        }

        // Silent rotation: if not client side, we don't touch camera
        // The actual packet sending with modified angles happens via network interceptors
        // For a simplified implementation without ASM network interception,
        // we temporarily rotate, let tick run, then restore
        if (!ka.clientSideRotation && ka.hasTarget(client)) {
            // Store current rotation
            float savedYaw = client.player.getYaw();
            float savedPitch = client.player.getPitch();

            // Set server rotation
            client.player.setYaw(ka.getServerYaw());
            client.player.setPitch(ka.getServerPitch());

            // Rotation will be used for this tick's packets
            // Will be restored in HEAD of next render via RenderMixin
        }
    }
}
