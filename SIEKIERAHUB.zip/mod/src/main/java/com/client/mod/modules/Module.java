package com.client.mod.modules;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.util.InputUtil;
import org.lwjgl.glfw.GLFW;

public abstract class Module {
    public String name;
    public String description;
    public boolean enabled = false;
    public int keybind = -1; // GLFW key code, -1 = none
    public boolean _wasKeyDown = false;

    public Module(String name, String description) {
        this.name = name;
        this.description = description;
    }

    public void toggle() {
        enabled = !enabled;
        if (enabled) onEnable();
        else onDisable();
    }

    public void setEnabled(boolean v) {
        if (v != enabled) toggle();
    }

    public void onEnable() {}
    public void onDisable() {}
    public void onTick(MinecraftClient client) {}

    public boolean isKeyDown(MinecraftClient client, int key) {
        return InputUtil.isKeyPressed(client.getWindow().getHandle(), key);
    }
}
