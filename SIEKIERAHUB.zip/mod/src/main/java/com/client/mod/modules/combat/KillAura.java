package com.client.mod.modules.combat;

import com.client.mod.modules.Module;
import net.minecraft.client.MinecraftClient;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.mob.MobEntity;
import net.minecraft.entity.passive.AnimalEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.util.math.Vec3d;

import java.util.Comparator;
import java.util.List;
import java.util.Random;
import java.util.stream.Collectors;

public class KillAura extends Module {

    // === ROTATION MODE ===
    public enum RotationMode {
        HVH, POLAR, GRIM, VULCAN, NONE
    }
    public RotationMode rotationMode = RotationMode.GRIM;

    // === TARGET FILTER ===
    public boolean targetPlayers = true;
    public boolean targetMobs = true;
    public boolean targetAnimals = false;
    public boolean targetPassive = false;

    // === RANGE ===
    public float attackRange = 3.5f;
    public float wallRange = 0.0f;
    public boolean hitThroughWalls = false;

    // === ROTATION OPTIONS ===
    public boolean clientSideRotation = false;
    public boolean moveFix = true;
    public boolean moveFixFocused = false; // false=free, true=focused

    // === MISC ===
    public int attackDelay = 10; // ticks between attacks
    public boolean swing = true;

    private int ticksSinceAttack = 0;
    private float serverYaw = 0, serverPitch = 0;
    private final Random random = new Random();

    public KillAura() {
        super("KillAura", "Automatycznie atakuje pobliskie cele");
    }

    @Override
    public void onTick(MinecraftClient client) {
        if (client.player == null || client.world == null) return;

        ticksSinceAttack++;

        Entity target = findTarget(client);
        if (target == null) return;

        // Calculate rotation to target
        float[] rotation = calculateRotation(client, target);

        // Apply rotation based on mode
        applyRotation(client, rotation, target);

        // Attack
        if (ticksSinceAttack >= attackDelay) {
            if (client.player.getAttackCooldownProgress(0) >= 1.0f || attackDelay > 0) {
                performAttack(client, target);
                ticksSinceAttack = 0;
            }
        }
    }

    private Entity findTarget(MinecraftClient client) {
        List<Entity> entities = client.world.getEntities().stream()
                .filter(e -> isValidTarget(client, e))
                .sorted(Comparator.comparingDouble(e -> e.distanceTo(client.player)))
                .collect(Collectors.toList());

        if (entities.isEmpty()) return null;
        return entities.get(0);
    }

    private boolean isValidTarget(MinecraftClient client, Entity e) {
        if (e == client.player) return false;
        if (!(e instanceof LivingEntity living)) return false;
        if (living.isDead() || living.getHealth() <= 0) return false;

        if (e instanceof PlayerEntity && !targetPlayers) return false;
        if (e instanceof MobEntity && !targetMobs) return false;
        if (e instanceof AnimalEntity && !targetAnimals) return false;

        float range = attackRange;
        double dist = client.player.distanceTo(e);

        if (!hasLineOfSight(client, e)) {
            if (!hitThroughWalls) return false;
            if (dist > wallRange) return false;
        } else {
            if (dist > range) return false;
        }

        return true;
    }

    private boolean hasLineOfSight(MinecraftClient client, Entity target) {
        return client.player.canSee(target);
    }

    private float[] calculateRotation(MinecraftClient client, Entity target) {
        Vec3d playerPos = client.player.getEyePos();
        Vec3d targetPos = target.getEyePos();

        double dx = targetPos.x - playerPos.x;
        double dy = targetPos.y - playerPos.y;
        double dz = targetPos.z - playerPos.z;
        double dist = Math.sqrt(dx * dx + dz * dz);

        float yaw = (float)(Math.toDegrees(Math.atan2(dz, dx)) - 90);
        float pitch = (float)(-Math.toDegrees(Math.atan2(dy, dist)));

        // Apply rotation mode modifications
        switch (rotationMode) {
            case HVH -> {
                // HvH: sometimes 360 snap
                if (random.nextInt(100) < 5) {
                    yaw += 360 * (random.nextBoolean() ? 1 : -1);
                }
                yaw += (random.nextFloat() - 0.5f) * 2f;
            }
            case POLAR -> {
                // Polar: smooth with slight randomization
                yaw = smoothYaw(client.player.getYaw(), yaw, 0.85f);
                yaw += (random.nextFloat() - 0.5f) * 1.5f;
            }
            case GRIM -> {
                // Grim: precise, minimal randomization
                yaw += (random.nextFloat() - 0.5f) * 0.5f;
                pitch += (random.nextFloat() - 0.5f) * 0.3f;
            }
            case VULCAN -> {
                // Vulcan: smooth rotation
                yaw = smoothYaw(client.player.getYaw(), yaw, 0.75f);
                pitch = smoothPitch(client.player.getPitch(), pitch, 0.75f);
            }
            case NONE -> {
                // Default/None - sometimes 360
                if (random.nextInt(100) < 3) {
                    yaw += 360;
                }
            }
        }

        return new float[]{yaw, clampPitch(pitch)};
    }

    private float smoothYaw(float current, float target, float factor) {
        float diff = wrapDegrees(target - current);
        return current + diff * (1 - factor);
    }

    private float smoothPitch(float current, float target, float factor) {
        return current + (target - current) * (1 - factor);
    }

    private float wrapDegrees(float degrees) {
        degrees = degrees % 360;
        if (degrees >= 180) degrees -= 360;
        if (degrees < -180) degrees += 360;
        return degrees;
    }

    private float clampPitch(float pitch) {
        return Math.max(-90, Math.min(90, pitch));
    }

    private void applyRotation(MinecraftClient client, float[] rotation, Entity target) {
        serverYaw = rotation[0];
        serverPitch = rotation[1];

        if (clientSideRotation) {
            // Rotate player camera
            client.player.setYaw(rotation[0]);
            client.player.setPitch(rotation[1]);
        }
        // else: silent rotation - only sent in packets via mixin
    }

    private void performAttack(MinecraftClient client, Entity target) {
        client.interactionManager.attackEntity(client.player, target);
        if (swing) {
            client.player.swingHand(net.minecraft.util.Hand.MAIN_HAND);
        }
    }

    // Called by mixin to get server-side rotation
    public float getServerYaw() { return serverYaw; }
    public float getServerPitch() { return serverPitch; }
    public boolean hasTarget(MinecraftClient client) {
        return client.player != null && client.world != null && findTarget(client) != null;
    }

    @Override
    public void onDisable() {
        serverYaw = 0;
        serverPitch = 0;
        ticksSinceAttack = 0;
    }
}
