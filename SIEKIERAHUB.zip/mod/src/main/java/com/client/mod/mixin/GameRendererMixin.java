package com.client.mod.mixin;

import com.client.mod.ClientMod;
import com.client.mod.modules.combat.KillAura;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.render.GameRenderer;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(GameRenderer.class)
public class GameRendererMixin {
    // This mixin is a placeholder for future rendering hooks
    @Inject(method = "render", at = @At("HEAD"))
    private void onRenderHead(net.minecraft.client.util.math.MatrixStack matrices, float tickDelta, long startTime, boolean tick, CallbackInfo ci) {
        // Can be used for future rendering hooks
    }
}
