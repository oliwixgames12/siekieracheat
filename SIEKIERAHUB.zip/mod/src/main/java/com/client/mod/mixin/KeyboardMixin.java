package com.client.mod.mixin;

import com.client.mod.ClientMod;
import net.minecraft.client.Keyboard;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(Keyboard.class)
public class KeyboardMixin {

    @Inject(method = "onKey", at = @At("HEAD"))
    private void onKey(long window, int key, int scancode, int action, int modifiers, CallbackInfo ci) {
        if (action == 1 || action == 2) {
            if (ClientMod.clickGui != null && ClientMod.clickGui.isVisible()) {
                ClientMod.clickGui.keyPressed(key, scancode);
            }
        }
    }

    @Inject(method = "onChar", at = @At("HEAD"))
    private void onChar(long window, int codePoint, int modifiers, CallbackInfo ci) {
        if (ClientMod.clickGui != null && ClientMod.clickGui.isVisible()) {
            ClientMod.clickGui.charTyped((char) codePoint);
        }
    }
}
