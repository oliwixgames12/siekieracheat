package com.client.mod.mixin;

import com.client.mod.ClientMod;
import net.minecraft.client.Mouse;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(Mouse.class)
public class MouseMixin {

    @Inject(method = "onMouseButton", at = @At("HEAD"))
    private void onMouseButton(long window, int button, int action, int mods, CallbackInfo ci) {
        if (ClientMod.clickGui == null || !ClientMod.clickGui.isVisible()) return;
        Mouse mouse = (Mouse)(Object)this;
        double mx = mouse.getX();
        double my = mouse.getY();
        if (action == 1) { // press
            ClientMod.clickGui.mouseClicked(mx, my, button);
        } else if (action == 0) { // release
            ClientMod.clickGui.mouseReleased(mx, my, button);
        }
    }

    @Inject(method = "onCursorPos", at = @At("HEAD"))
    private void onCursorPos(long window, double x, double y, CallbackInfo ci) {
        if (ClientMod.clickGui != null && ClientMod.clickGui.isVisible()) {
            ClientMod.clickGui.mouseMoved(x, y);
        }
    }
}
