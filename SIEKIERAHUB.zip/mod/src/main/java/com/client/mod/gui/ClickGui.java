package com.client.mod.gui;

import com.client.mod.ClientMod;
import com.client.mod.modules.Module;
import com.client.mod.modules.combat.KillAura;
import com.client.mod.modules.world.AutoTrap;
import com.client.mod.modules.world.AutoWeb;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.util.InputUtil;
import org.lwjgl.glfw.GLFW;

import java.util.HashMap;
import java.util.Map;

public class ClickGui {

    private boolean visible = false;
    private int guiX = 50, guiY = 50;
    private boolean dragging = false;
    private int dragOffX, dragOffY;
    private boolean _wasShiftDown = false;

    // Keybind capture
    private Module bindingModule = null;

    // Text field focus (dla block ID)
    private boolean blockIdFocused = false;

    // Panel sizes
    private static final int PANEL_W = 260;
    private static final int HEADER_H = 22;
    private static final int ITEM_H = 20;
    private static final int PADDING = 8;

    private Map<String, Float> hoverMap = new HashMap<>();

    public void onTick(MinecraftClient client) {
        if (client == null) return;
        boolean shiftDown = InputUtil.isKeyPressed(client.getWindow().getHandle(), GLFW.GLFW_KEY_RIGHT_SHIFT);
        if (shiftDown && !_wasShiftDown) {
            visible = !visible;
            if (visible) {
                client.mouse.unlockCursor();
            } else {
                if (client.currentScreen == null) client.mouse.lockCursor();
                bindingModule = null;
                blockIdFocused = false;
            }
        }
        _wasShiftDown = shiftDown;
    }

    public void render(DrawContext ctx) {
        if (!visible) return;
        MinecraftClient client = MinecraftClient.getInstance();
        TextRenderer tr = client.textRenderer;

        Module[] modules = {
            ClientMod.moduleManager.killAura,
            ClientMod.moduleManager.autoTrap,
            ClientMod.moduleManager.autoWeb
        };

        int panelH = HEADER_H + PADDING;
        for (Module m : modules) {
            panelH += ITEM_H;
            if (m.enabled) panelH += getModuleSettingsHeight(m);
        }
        panelH += PADDING;

        drawPanel(ctx, guiX, guiY, PANEL_W, panelH);
        ctx.drawText(tr, "§b§lClientMod", guiX + PADDING, guiY + 6, 0xFFFFFF, true);

        int y = guiY + HEADER_H;
        for (Module m : modules) {
            float hover = hoverMap.getOrDefault(m.name, 0f);
            boolean hovered = isMouseInside(getMouseX(), getMouseY(), guiX + PADDING, y, PANEL_W - PADDING*2, ITEM_H);
            hover += hovered ? 0.15f : -0.15f;
            hover = Math.max(0, Math.min(1, hover));
            hoverMap.put(m.name, hover);

            int rowBg = m.enabled
                ? blendColor(0xFF1a3a1a, 0xFF2a5a2a, hover)
                : blendColor(0xFF1a1a2e, 0xFF252545, hover);
            ctx.fill(guiX + PADDING, y, guiX + PANEL_W - PADDING, y + ITEM_H, rowBg | 0xFF000000);

            // Status dot
            ctx.fill(guiX + PADDING + 4, y + 7, guiX + PADDING + 9, y + 13, m.enabled ? 0xFF44FF44 : 0xFF555555);

            // Name
            String displayName = (bindingModule == m) ? "§e[Press key...]" : m.name;
            ctx.drawText(tr, displayName, guiX + PADDING + 14, y + 6, m.enabled ? 0xAAFFAA : 0xCCCCCC, false);

            // Keybind
            String keyStr = m.keybind == -1 ? "§7[NONE]" : "§e[" + GLFW.glfwGetKeyName(m.keybind, 0) + "]";
            ctx.drawText(tr, keyStr, guiX + PANEL_W - PADDING - tr.getWidth(keyStr) - 4, y + 6, 0xFFFFFF, false);

            y += ITEM_H;

            if (m.enabled) {
                y = renderModuleSettings(ctx, tr, m, y);
            }
        }

        // Keybind prompt
        if (bindingModule != null) {
            String msg = "§fKlawisz dla §b" + bindingModule.name + " §7(ESC=brak)";
            ctx.fill(guiX, guiY + panelH + 4, guiX + PANEL_W, guiY + panelH + 18, 0xCC000000);
            ctx.drawText(tr, msg, guiX + PADDING, guiY + panelH + 7, 0xFFFFFF, false);
        }
    }

    private int renderModuleSettings(DrawContext ctx, TextRenderer tr, Module m, int y) {
        if (m instanceof KillAura ka) return renderKillAuraSettings(ctx, tr, ka, y);
        if (m instanceof AutoTrap at) return renderAutoTrapSettings(ctx, tr, at, y);
        if (m instanceof AutoWeb aw) return renderAutoWebSettings(ctx, tr, aw, y);
        return y;
    }

    private int renderKillAuraSettings(DrawContext ctx, TextRenderer tr, KillAura ka, int y) {
        int x = guiX + PADDING + 6, w = PANEL_W - PADDING*2 - 6;

        y = renderLabel(ctx, tr, x, y, "Rotation:");
        for (KillAura.RotationMode mode : KillAura.RotationMode.values()) {
            final KillAura.RotationMode m2 = mode;
            y = renderToggle(ctx, tr, x, y, w, mode.name(), ka.rotationMode == mode, () -> ka.rotationMode = m2);
        }
        y = renderLabel(ctx, tr, x, y, "Targets:");
        y = renderCheckbox(ctx, tr, x, y, w, "Players", ka.targetPlayers, () -> ka.targetPlayers = !ka.targetPlayers);
        y = renderCheckbox(ctx, tr, x, y, w, "Mobs", ka.targetMobs, () -> ka.targetMobs = !ka.targetMobs);
        y = renderCheckbox(ctx, tr, x, y, w, "Animals", ka.targetAnimals, () -> ka.targetAnimals = !ka.targetAnimals);
        y = renderLabel(ctx, tr, x, y, "Attack Range: " + String.format("%.1f", ka.attackRange));
        y = renderSlider(ctx, tr, x, y, w, ka.attackRange, 1f, 6f, v -> ka.attackRange = v);
        y = renderCheckbox(ctx, tr, x, y, w, "Through Walls", ka.hitThroughWalls, () -> ka.hitThroughWalls = !ka.hitThroughWalls);
        if (ka.hitThroughWalls) {
            y = renderLabel(ctx, tr, x, y, "Wall Range: " + String.format("%.1f", ka.wallRange));
            y = renderSlider(ctx, tr, x, y, w, ka.wallRange, 0f, 6f, v -> ka.wallRange = v);
        }
        y = renderLabel(ctx, tr, x, y, "Rotation Options:");
        y = renderCheckbox(ctx, tr, x, y, w, "Client Side Rotation", ka.clientSideRotation, () -> ka.clientSideRotation = !ka.clientSideRotation);
        y = renderCheckbox(ctx, tr, x, y, w, "Move Fix", ka.moveFix, () -> ka.moveFix = !ka.moveFix);
        if (ka.moveFix) {
            y = renderCheckbox(ctx, tr, x, y, w, "Focused (W=to target)", ka.moveFixFocused, () -> ka.moveFixFocused = !ka.moveFixFocused);
        }
        y = renderLabel(ctx, tr, x, y, "Attack Delay: " + ka.attackDelay + "t");
        y = renderSlider(ctx, tr, x, y, w, ka.attackDelay, 0, 20, v -> ka.attackDelay = (int)v);
        y = renderCheckbox(ctx, tr, x, y, w, "Swing Arm", ka.swing, () -> ka.swing = !ka.swing);
        return y;
    }

    private int renderAutoTrapSettings(DrawContext ctx, TextRenderer tr, AutoTrap at, int y) {
        int x = guiX + PADDING + 6, w = PANEL_W - PADDING*2 - 6;
        MinecraftClient client = MinecraftClient.getInstance();

        // === POLE TEKSTOWE DLA ID BLOKU ===
        y = renderLabel(ctx, tr, x, y, "Block ID:");
        y = renderTextInput(ctx, tr, x, y, w, at.blockId, at.isBlockValid(),
            val -> at.blockId = val, "blockId_autotrap");

        y = renderLabel(ctx, tr, x, y, "Mode:");
        for (AutoTrap.PlaceMode pm : AutoTrap.PlaceMode.values()) {
            final AutoTrap.PlaceMode pmc = pm;
            y = renderToggle(ctx, tr, x, y, w, pm.name(), at.placeMode == pm, () -> at.placeMode = pmc);
        }
        if (at.placeMode == AutoTrap.PlaceMode.INSTANT) {
            y = renderLabel(ctx, tr, x, y, "Delay: " + at.instantDelay + "t");
            y = renderSlider(ctx, tr, x, y, w, at.instantDelay, 0, 10, v -> at.instantDelay = (int)v);
            y = renderLabel(ctx, tr, x, y, "Blocks/Tick: " + at.blocksPerTick);
            y = renderSlider(ctx, tr, x, y, w, at.blocksPerTick, 1, 5, v -> at.blocksPerTick = (int)v);
        }
        y = renderLabel(ctx, tr, x, y, "Build Mode:");
        for (AutoTrap.BuildMode bm : AutoTrap.BuildMode.values()) {
            final AutoTrap.BuildMode bmc = bm;
            y = renderToggle(ctx, tr, x, y, w, bm.name(), at.buildMode == bm, () -> at.buildMode = bmc);
        }
        y = renderLabel(ctx, tr, x, y, "Use Mode:");
        for (AutoTrap.UseMode um : AutoTrap.UseMode.values()) {
            final AutoTrap.UseMode umc = um;
            y = renderToggle(ctx, tr, x, y, w, um.name(), at.useMode == um, () -> at.useMode = umc);
        }
        y = renderCheckbox(ctx, tr, x, y, w, "Rotate", at.rotate, () -> at.rotate = !at.rotate);
        if (at.rotate) {
            y = renderCheckbox(ctx, tr, x, y, w, "Grim Silent", at.grimSilent, () -> at.grimSilent = !at.grimSilent);
        }
        y = renderCheckbox(ctx, tr, x, y, w, "Render", at.render, () -> at.render = !at.render);
        return y;
    }

    private int renderAutoWebSettings(DrawContext ctx, TextRenderer tr, AutoWeb aw, int y) {
        int x = guiX + PADDING + 6, w = PANEL_W - PADDING*2 - 6;
        y = renderLabel(ctx, tr, x, y, "Mode:");
        for (AutoWeb.PlaceMode pm : AutoWeb.PlaceMode.values()) {
            final AutoWeb.PlaceMode pmc = pm;
            y = renderToggle(ctx, tr, x, y, w, pm.name(), aw.placeMode == pm, () -> aw.placeMode = pmc);
        }
        if (aw.placeMode == AutoWeb.PlaceMode.INSTANT) {
            y = renderLabel(ctx, tr, x, y, "Delay: " + aw.instantDelay + "t");
            y = renderSlider(ctx, tr, x, y, w, aw.instantDelay, 0, 10, v -> aw.instantDelay = (int)v);
            y = renderLabel(ctx, tr, x, y, "Blocks/Tick: " + aw.blocksPerTick);
            y = renderSlider(ctx, tr, x, y, w, aw.blocksPerTick, 1, 5, v -> aw.blocksPerTick = (int)v);
        }
        y = renderLabel(ctx, tr, x, y, "Build Mode:");
        for (AutoWeb.BuildMode bm : AutoWeb.BuildMode.values()) {
            final AutoWeb.BuildMode bmc = bm;
            y = renderToggle(ctx, tr, x, y, w, bm.name(), aw.buildMode == bm, () -> aw.buildMode = bmc);
        }
        y = renderLabel(ctx, tr, x, y, "Use Mode:");
        for (AutoWeb.UseMode um : AutoWeb.UseMode.values()) {
            final AutoWeb.UseMode umc = um;
            y = renderToggle(ctx, tr, x, y, w, um.name(), aw.useMode == um, () -> aw.useMode = umc);
        }
        y = renderCheckbox(ctx, tr, x, y, w, "Rotate", aw.rotate, () -> aw.rotate = !aw.rotate);
        if (aw.rotate) {
            y = renderCheckbox(ctx, tr, x, y, w, "Grim Silent", aw.grimSilent, () -> aw.grimSilent = !aw.grimSilent);
        }
        y = renderCheckbox(ctx, tr, x, y, w, "Web Head", aw.webHead, () -> aw.webHead = !aw.webHead);
        y = renderCheckbox(ctx, tr, x, y, w, "Render", aw.render, () -> aw.render = !aw.render);
        return y;
    }

    // ==================== TEXT INPUT FIELD ====================
    // focusKey - unikalny klucz dla tego pola
    private String focusedFieldKey = null;

    private int renderTextInput(DrawContext ctx, TextRenderer tr, int x, int y, int w,
                                String currentValue, boolean valid,
                                java.util.function.Consumer<String> onChange, String fieldKey) {
        int fh = 16;
        boolean focused = fieldKey.equals(focusedFieldKey);

        // Tło pola
        int borderColor = focused ? 0xFF4488FF : (valid ? 0xFF335533 : 0xFF553333);
        ctx.fill(x, y, x + w, y + fh, 0xFF111122);
        ctx.fill(x, y, x + w, y + 1, borderColor);
        ctx.fill(x, y + fh - 1, x + w, y + fh, borderColor);
        ctx.fill(x, y, x + 1, y + fh, borderColor);
        ctx.fill(x + w - 1, y, x + w, y + fh, borderColor);

        // Tekst
        String display = currentValue;
        if (focused) display = display + "§f|"; // kursor
        String color = valid ? "§a" : "§c";
        ctx.drawText(tr, color + display, x + 3, y + 4, 0xFFFFFF, false);

        // Klik = fokus
        if (isMouseInside(getMouseX(), getMouseY(), x, y, w, fh) && isLeftClick()) {
            focusedFieldKey = fieldKey;
            bindingModule = null; // anuluj keybind jeśli klikamy w text field
        }

        // Walidacja - mały hint
        if (!valid && !currentValue.isEmpty()) {
            ctx.drawText(tr, "§c✗ nieznany blok", x + 3, y + fh + 1, 0xFF5555, false);
            return y + fh + 12;
        }

        return y + fh + 4;
    }

    // ==================== UI PRIMITIVES ====================

    private int renderLabel(DrawContext ctx, TextRenderer tr, int x, int y, String text) {
        ctx.drawText(tr, "§8" + text, x, y + 3, 0xAAAAAA, false);
        return y + 13;
    }

    private int renderCheckbox(DrawContext ctx, TextRenderer tr, int x, int y, int w, String label, boolean checked, Runnable onClick) {
        boolean hover = isMouseInside(getMouseX(), getMouseY(), x, y, w, ITEM_H - 2);
        ctx.fill(x, y, x + w, y + ITEM_H - 2, hover ? 0xFF2a2a3e : 0xFF1e1e2e);
        ctx.fill(x + 2, y + 4, x + 12, y + 14, 0xFF333355);
        if (checked) ctx.fill(x + 4, y + 6, x + 10, y + 12, 0xFF44AAFF);
        ctx.drawText(tr, label, x + 16, y + 5, hover ? 0xFFFFFF : 0xCCCCCC, false);
        if (hover && isLeftClick()) onClick.run();
        return y + ITEM_H;
    }

    private int renderToggle(DrawContext ctx, TextRenderer tr, int x, int y, int w, String label, boolean selected, Runnable onClick) {
        boolean hover = isMouseInside(getMouseX(), getMouseY(), x, y, w, ITEM_H - 2);
        ctx.fill(x, y, x + w, y + ITEM_H - 2, selected ? 0xFF1a3050 : (hover ? 0xFF252535 : 0xFF1a1a2a));
        ctx.drawText(tr, (selected ? "§b● " : "§8○ ") + label, x + 4, y + 5, selected ? 0x88DDFF : (hover ? 0xCCCCCC : 0x888888), false);
        if (hover && isLeftClick()) onClick.run();
        return y + ITEM_H;
    }

    private int renderSlider(DrawContext ctx, TextRenderer tr, int x, int y, int w, float value, float min, float max, java.util.function.Consumer<Float> onChange) {
        int sh = 10, sw = w - 4;
        ctx.fill(x + 2, y + 3, x + 2 + sw, y + 3 + sh - 6, 0xFF333355);
        float t = (value - min) / (max - min);
        int fillW = (int)(sw * t);
        ctx.fill(x + 2, y + 3, x + 2 + fillW, y + 3 + sh - 6, 0xFF4488CC);
        ctx.fill(x + 2 + fillW - 2, y + 1, x + 2 + fillW + 2, y + sh - 1, 0xFFAADDFF);
        if (isMouseInside(getMouseX(), getMouseY(), x + 2, y, sw, sh) && isLeftDown()) {
            float newT = (float)(getMouseX() - (x + 2)) / sw;
            onChange.accept(min + Math.max(0, Math.min(1, newT)) * (max - min));
        }
        return y + sh + 2;
    }

    private void drawPanel(DrawContext ctx, int x, int y, int w, int h) {
        ctx.fill(x + 3, y + 3, x + w + 3, y + h + 3, 0x44000000);
        ctx.fill(x, y, x + w, y + h, 0xEE0D0D1A);
        ctx.fill(x, y, x + w, y + 1, 0xFF3366AA);
        ctx.fill(x, y + h - 1, x + w, y + h, 0xFF224477);
        ctx.fill(x, y, x + 1, y + h, 0xFF3366AA);
        ctx.fill(x + w - 1, y, x + w, y + h, 0xFF224477);
        ctx.fill(x, y + HEADER_H, x + w, y + HEADER_H + 1, 0xFF3366AA);
    }

    private int blendColor(int c1, int c2, float t) {
        int r = ((c1>>16)&0xFF) + (int)((((c2>>16)&0xFF)-((c1>>16)&0xFF))*t);
        int g = ((c1>>8)&0xFF) + (int)((((c2>>8)&0xFF)-((c1>>8)&0xFF))*t);
        int b = (c1&0xFF) + (int)(((c2&0xFF)-(c1&0xFF))*t);
        return (r<<16)|(g<<8)|b;
    }

    // ==================== INPUT ====================
    private double mouseX, mouseY;
    private boolean leftClick = false;
    private boolean leftDown = false;

    public void mouseClicked(double x, double y, int button) {
        mouseX = x; mouseY = y;
        if (!visible) return;
        if (button == 0) {
            leftClick = true;
            leftDown = true;

            // Klik poza text fieldem - odznacz fokus
            boolean clickedInField = false;
            // (sprawdzamy w renderze, tu resetujemy)
            // Jeśli kliknięto poza GUI - zamknij
            // Na razie: klik w module toggle
            int yy = guiY + HEADER_H;
            Module[] modules = {
                ClientMod.moduleManager.killAura,
                ClientMod.moduleManager.autoTrap,
                ClientMod.moduleManager.autoWeb
            };
            for (Module m : modules) {
                if (isMouseInside(x, y, guiX + PADDING, yy, PANEL_W - PADDING*2, ITEM_H)) {
                    if (x > guiX + PANEL_W - 60) {
                        bindingModule = m;
                        focusedFieldKey = null;
                    } else {
                        m.toggle();
                    }
                    return;
                }
                yy += ITEM_H;
                if (m.enabled) yy += getModuleSettingsHeight(m);
            }
            if (isMouseInside(x, y, guiX, guiY, PANEL_W, HEADER_H)) {
                dragging = true;
                dragOffX = (int)(x - guiX);
                dragOffY = (int)(y - guiY);
            }
        }
    }

    public void mouseReleased(double x, double y, int button) {
        if (button == 0) { dragging = false; leftClick = false; leftDown = false; }
    }

    public void mouseMoved(double x, double y) {
        mouseX = x; mouseY = y;
        if (dragging) { guiX = (int)(x - dragOffX); guiY = (int)(y - dragOffY); }
    }

    public void keyPressed(int keyCode, int scancode) {
        // Jeśli aktywny text field
        if (focusedFieldKey != null) {
            if (focusedFieldKey.equals("blockId_autotrap")) {
                AutoTrap at = ClientMod.moduleManager.autoTrap;
                at.blockId = handleTextInput(at.blockId, keyCode);
            }
            if (keyCode == GLFW.GLFW_KEY_ESCAPE || keyCode == GLFW.GLFW_KEY_ENTER) {
                focusedFieldKey = null;
            }
            return;
        }

        // Keybind capture
        if (bindingModule != null) {
            bindingModule.keybind = (keyCode == GLFW.GLFW_KEY_ESCAPE) ? -1 : keyCode;
            bindingModule = null;
            return;
        }
    }

    public void charTyped(char chr) {
        if (focusedFieldKey == null) return;
        if (focusedFieldKey.equals("blockId_autotrap")) {
            AutoTrap at = ClientMod.moduleManager.autoTrap;
            // Dopuszczaj litery, cyfry, dwukropek, podkreślnik
            if (Character.isLetterOrDigit(chr) || chr == ':' || chr == '_') {
                at.blockId += chr;
            }
        }
    }

    private String handleTextInput(String current, int keyCode) {
        if (keyCode == GLFW.GLFW_KEY_BACKSPACE && !current.isEmpty()) {
            return current.substring(0, current.length() - 1);
        }
        return current;
    }

    // Stub - keyPressed with 2 params called from mixin
    public void keyPressed(int keyCode) {
        keyPressed(keyCode, 0);
    }

    private boolean isMouseInside(double mx, double my, int x, int y, int w, int h) {
        return mx >= x && mx < x + w && my >= y && my < y + h;
    }
    private double getMouseX() { return mouseX; }
    private double getMouseY() { return mouseY; }
    private boolean isLeftClick() { return leftClick; }
    private boolean isLeftDown() { return leftDown; }
    public boolean isVisible() { return visible; }

    private int getModuleSettingsHeight(Module m) {
        if (m instanceof KillAura ka) {
            int h = 13 + 5*ITEM_H + 13 + 3*ITEM_H + 13 + 16 + ITEM_H;
            if (ka.hitThroughWalls) h += 13 + 16;
            h += 13 + 2*ITEM_H;
            if (ka.moveFix) h += ITEM_H;
            h += 13 + 16 + ITEM_H;
            return h;
        }
        if (m instanceof AutoTrap at) {
            // Block ID text field (16+4) + ewentualny błąd (12) + label (13)
            int h = 13 + 20 + (at.isBlockValid() ? 0 : 12);
            h += 13 + 2*ITEM_H; // mode
            if (at.placeMode == AutoTrap.PlaceMode.INSTANT) h += 2*(13+16);
            h += 13 + 4*ITEM_H + 13 + 3*ITEM_H;
            h += ITEM_H;
            if (at.rotate) h += ITEM_H;
            h += ITEM_H;
            return h;
        }
        if (m instanceof AutoWeb aw) {
            int h = 13 + 2*ITEM_H;
            if (aw.placeMode == AutoWeb.PlaceMode.INSTANT) h += 2*(13+16);
            h += 13 + 4*ITEM_H + 13 + 3*ITEM_H + ITEM_H;
            if (aw.rotate) h += ITEM_H;
            h += 2*ITEM_H;
            return h;
        }
        return 0;
    }

    private int getExtraHeight() {
        Module[] modules = {
            ClientMod.moduleManager.killAura,
            ClientMod.moduleManager.autoTrap,
            ClientMod.moduleManager.autoWeb
        };
        int extra = 0;
        for (Module m : modules) {
            if (m.enabled) extra += getModuleSettingsHeight(m);
        }
        return extra;
    }
}
