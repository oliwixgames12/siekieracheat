package com.client.mod.modules.world;

import com.client.mod.modules.Module;
import net.minecraft.block.Blocks;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.BlockItem;
import net.minecraft.item.ItemStack;
import net.minecraft.util.Hand;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;
import net.minecraft.util.math.Vec3d;

public class AutoWeb extends Module {

    // Same settings as AutoTrap minus block choice
    public enum PlaceMode { VANILLA, INSTANT }
    public PlaceMode placeMode = PlaceMode.VANILLA;
    public int instantDelay = 2;
    public int blocksPerTick = 1;

    public enum BuildMode { AIRPLACE, VANILLA, STRICT, GRIM }
    public BuildMode buildMode = BuildMode.GRIM;

    public enum UseMode { SILENT, ALTERNATIVE, NORMAL }
    public UseMode useMode = UseMode.SILENT;

    public boolean rotate = false;
    public boolean grimSilent = false;
    public boolean render = true;

    // Web specific
    public boolean webHead = true; // web at head level

    private int tickTimer = 0;

    public AutoWeb() {
        super("AutoWeb", "Automatycznie stawia pajęczyny na przeciwnikach");
    }

    @Override
    public void onTick(MinecraftClient client) {
        if (client.player == null || client.world == null) return;

        PlayerEntity target = findNearestPlayer(client);
        if (target == null) return;

        tickTimer++;
        int delay = placeMode == PlaceMode.INSTANT ? instantDelay : 4;
        if (tickTimer < delay) return;
        tickTimer = 0;

        BlockPos feet = target.getBlockPos();
        int placed = 0;

        for (int i = 0; i <= (webHead ? 1 : 0) && placed < blocksPerTick; i++) {
            BlockPos pos = feet.up(i);
            if (client.world.getBlockState(pos).isAir()) {
                placeWeb(client, pos);
                placed++;
            }
        }
    }

    private PlayerEntity findNearestPlayer(MinecraftClient client) {
        PlayerEntity nearest = null;
        double minDist = Double.MAX_VALUE;
        for (PlayerEntity p : client.world.getPlayers()) {
            if (p == client.player) continue;
            double d = p.distanceTo(client.player);
            if (d < 6 && d < minDist) {
                minDist = d;
                nearest = p;
            }
        }
        return nearest;
    }

    private void placeWeb(MinecraftClient client, BlockPos pos) {
        int slot = findWeb(client);
        if (slot == -1) return;

        if (useMode == UseMode.SILENT) {
            int prev = client.player.getInventory().selectedSlot;
            client.player.getInventory().selectedSlot = slot;
            doPlace(client, pos);
            client.player.getInventory().selectedSlot = prev;
        } else if (useMode == UseMode.NORMAL) {
            if (client.player.getInventory().selectedSlot == slot) doPlace(client, pos);
        } else {
            doPlace(client, pos);
        }
    }

    private void doPlace(MinecraftClient client, BlockPos pos) {
        for (Direction dir : Direction.values()) {
            BlockPos neighbor = pos.offset(dir);
            if (!client.world.getBlockState(neighbor).isAir()) {
                if (rotate && !grimSilent) {
                    Vec3d center = Vec3d.ofCenter(pos);
                    Vec3d eye = client.player.getEyePos();
                    double dx = center.x - eye.x, dy = center.y - eye.y, dz = center.z - eye.z;
                    double dist = Math.sqrt(dx*dx + dz*dz);
                    client.player.setYaw((float)(Math.toDegrees(Math.atan2(dz, dx)) - 90));
                    client.player.setPitch((float)(-Math.toDegrees(Math.atan2(dy, dist))));
                }
                BlockHitResult hit = new BlockHitResult(Vec3d.ofCenter(neighbor), dir.getOpposite(), neighbor, false);
                client.interactionManager.interactBlock(client.player, Hand.MAIN_HAND, hit);
                return;
            }
        }
    }

    private int findWeb(MinecraftClient client) {
        for (int i = 0; i < 9; i++) {
            ItemStack stack = client.player.getInventory().getStack(i);
            if (!stack.isEmpty() && stack.getItem() instanceof BlockItem bi) {
                if (bi.getBlock() == Blocks.COBWEB) return i;
            }
        }
        return -1;
    }
}
