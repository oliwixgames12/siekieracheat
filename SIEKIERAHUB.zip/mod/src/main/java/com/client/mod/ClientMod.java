package com.client.mod;

import com.client.mod.gui.ClickGui;
import com.client.mod.modules.ModuleManager;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.rendering.v1.HudRenderCallback;
import net.minecraft.client.MinecraftClient;

public class ClientMod implements ClientModInitializer {

    public static ClientMod INSTANCE;
    public static ModuleManager moduleManager;
    public static ClickGui clickGui;

    @Override
    public void onInitializeClient() {
        INSTANCE = this;
        moduleManager = new ModuleManager();
        clickGui = new ClickGui();

        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            if (client.player == null) return;
            moduleManager.onTick(client);
            clickGui.onTick(client);
        });

        HudRenderCallback.EVENT.register((drawContext, tickDeltaManager) -> {
            MinecraftClient client = MinecraftClient.getInstance();
            if (client.player == null) return;
            clickGui.render(drawContext);
        });
    }
}
