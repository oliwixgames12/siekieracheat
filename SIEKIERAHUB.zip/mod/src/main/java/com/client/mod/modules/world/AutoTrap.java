package com.client.mod.modules.world;

import com.client.mod.modules.Module;
import net.minecraft.block.Block;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.BlockItem;
import net.minecraft.item.ItemStack;
import net.minecraft.registry.Registries;
import net.minecraft.util.Hand;
import net.minecraft.util.Identifier;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;
import net.minecraft.util.math.Vec3d;

import java.util.ArrayList;
import java.util.List;

public class AutoTrap extends Module {

    // Dowolny blok wpisany przez gracza w formacie minecraft:obsidian
    public String blockId = "minecraft:obsidian";
    private Block resolvedBlock = null;
    private String lastResolvedId = "";

    public enum PlaceMode { VANILLA, INSTANT }
    public PlaceMode placeMode = PlaceMode.VANILLA;
    public int instantDelay = 2;
    public int blocksPerTick = 1;

    public enum BuildMode { AIRPLACE, VANILLA, STRICT, GRIM }
    public BuildMode buildMode = BuildMode.GRIM;

    public enum UseMode { SILENT, ALTERNATIVE, NORMAL }
    public UseMode useMode = UseMode.SILENT;

    public boolean rotate = false;
    public boolean grimSilent = false;
    public boolean render = true;

    private int tickTimer = 0;
    private List<BlockPos> pendingBlocks = new ArrayList<>();
    private int placeIndex = 0;

    private static final int[][] TRAP_OFFSETS = {
        {1,0,0},{-1,0,0},{0,0,1},{0,0,-1},
        {1,1,0},{-1,1,0},{0,1,1},{0,1,-1},
        {0,2,0}
    };

    public AutoTrap() {
        super("AutoTrap", "Automatycznie buduje trap wokol gracza");
    }

    @Override
    public void onEnable() {
        pendingBlocks.clear();
        placeIndex = 0;
    }

    @Override
    public void onTick(MinecraftClient client) {
        if (client.player == null || client.world == null) return;
        PlayerEntity target = findNearestPlayer(client);
        if (target == null) return;

        BlockPos targetFeet = target.getBlockPos();
        pendingBlocks.clear();
        for (int[] off : TRAP_OFFSETS) {
            BlockPos pos = targetFeet.add(off[0], off[1], off[2]);
            if (client.world.getBlockState(pos).isAir()) pendingBlocks.add(pos);
        }
        if (pendingBlocks.isEmpty()) return;

        tickTimer++;
        int delay = placeMode == PlaceMode.INSTANT ? instantDelay : 4;
        if (tickTimer < delay) return;
        tickTimer = 0;

        int placed = 0;
        while (placeIndex < pendingBlocks.size() && placed < blocksPerTick) {
            placeBlock(client, pendingBlocks.get(placeIndex));
            placeIndex++;
            placed++;
        }
        if (placeIndex >= pendingBlocks.size()) placeIndex = 0;
    }

    private PlayerEntity findNearestPlayer(MinecraftClient client) {
        PlayerEntity nearest = null;
        double minDist = Double.MAX_VALUE;
        for (PlayerEntity p : client.world.getPlayers()) {
            if (p == client.player) continue;
            double d = p.distanceTo(client.player);
            if (d < 6 && d < minDist) { minDist = d; nearest = p; }
        }
        return nearest;
    }

    private void placeBlock(MinecraftClient client, BlockPos pos) {
        int slot = findBlock(client);
        if (slot == -1) return;
        if (useMode == UseMode.SILENT) {
            int prev = client.player.getInventory().selectedSlot;
            client.player.getInventory().selectedSlot = slot;
            doPlace(client, pos);
            client.player.getInventory().selectedSlot = prev;
        } else if (useMode == UseMode.NORMAL) {
            if (client.player.getInventory().selectedSlot == slot) doPlace(client, pos);
        } else {
            doPlace(client, pos);
        }
    }

    private void doPlace(MinecraftClient client, BlockPos pos) {
        for (Direction dir : Direction.values()) {
            BlockPos neighbor = pos.offset(dir);
            if (!client.world.getBlockState(neighbor).isAir()) {
                if (rotate && !grimSilent) rotateTowards(client, Vec3d.ofCenter(pos));
                BlockHitResult hit = new BlockHitResult(Vec3d.ofCenter(neighbor), dir.getOpposite(), neighbor, false);
                client.interactionManager.interactBlock(client.player, Hand.MAIN_HAND, hit);
                return;
            }
        }
    }

    private void rotateTowards(MinecraftClient client, Vec3d target) {
        Vec3d eye = client.player.getEyePos();
        double dx = target.x-eye.x, dy = target.y-eye.y, dz = target.z-eye.z;
        double dist = Math.sqrt(dx*dx+dz*dz);
        client.player.setYaw((float)(Math.toDegrees(Math.atan2(dz,dx))-90));
        client.player.setPitch((float)(-Math.toDegrees(Math.atan2(dy,dist))));
    }

    public Block getResolvedBlock() {
        if (!blockId.equals(lastResolvedId)) {
            lastResolvedId = blockId;
            try {
                resolvedBlock = Registries.BLOCK.get(Identifier.of(blockId));
            } catch (Exception e) {
                resolvedBlock = null;
            }
        }
        return resolvedBlock;
    }

    public boolean isBlockValid() {
        return getResolvedBlock() != null;
    }

    private int findBlock(MinecraftClient client) {
        Block target = getResolvedBlock();
        if (target == null) return -1;
        for (int i = 0; i < 9; i++) {
            ItemStack stack = client.player.getInventory().getStack(i);
            if (!stack.isEmpty() && stack.getItem() instanceof BlockItem bi && bi.getBlock() == target) return i;
        }
        return -1;
    }
}
