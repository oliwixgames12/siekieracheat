package com.client.mod.modules;

import com.client.mod.modules.combat.KillAura;
import com.client.mod.modules.world.AutoTrap;
import com.client.mod.modules.world.AutoWeb;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.util.InputUtil;

import java.util.ArrayList;
import java.util.List;

public class ModuleManager {
    public List<Module> modules = new ArrayList<>();

    public KillAura killAura;
    public AutoTrap autoTrap;
    public AutoWeb autoWeb;

    public ModuleManager() {
        killAura = new KillAura();
        autoTrap = new AutoTrap();
        autoWeb = new AutoWeb();

        modules.add(killAura);
        modules.add(autoTrap);
        modules.add(autoWeb);
    }

    public void onTick(MinecraftClient client) {
        for (Module m : modules) {
            // Check keybind
            if (m.keybind != -1) {
                boolean pressed = InputUtil.isKeyPressed(client.getWindow().getHandle(), m.keybind);
                if (pressed && !m._wasKeyDown) {
                    m.toggle();
                }
                m._wasKeyDown = pressed;
            }
            if (m.enabled) m.onTick(client);
        }
    }
}
